﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Joe_Final
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void LoginBtn_Click(object sender, EventArgs e)
        {
            string username = "Joe";
            string password = "Automaster35";
            if (this.UserNametxtBox.Text == username && this.PasswordtxtBox.Text == password)
            {
                this.Hide();
                Overview f2 = new Overview();
                f2.ShowDialog();
            }
            else
            {

                MessageBox.Show("Username Or Password Incorrect");
                    
            }
            
        }

        private void CancelBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
