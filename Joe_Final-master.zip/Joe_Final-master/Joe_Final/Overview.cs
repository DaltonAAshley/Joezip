﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Joe_Final
{
    public partial class Overview : Form
    {
        public Overview()
        {
            InitializeComponent();
        }

        private void Exitbtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void personnelBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.personnelBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.user_InfoDataSet1);

        }

        private void Overview_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'user_InfoDataSet1.Personnel' table. You can move, or remove it, as needed.
            this.personnelTableAdapter.Fill(this.user_InfoDataSet1.Personnel);

        }

        private void SearchBox_TextChanged(object sender, EventArgs e)
        {
            if (SearchBox.Text == "")
            {
                personnelTableAdapter.Fill(this.user_InfoDataSet1.Personnel);
            } else {
                personnelTableAdapter.FillSearchedPersonnel(this.user_InfoDataSet1.Personnel, SearchBox.Text);
            }
        }
    }
}
